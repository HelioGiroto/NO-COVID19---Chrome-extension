let expressao = document.body.textContent.match(/coronav.rus/gi)

if(expressao){
	let ocorrencias = ( expressao || [] ).length	
	alert(`Detectamos ${ocorrencias} corona(s) nesta página!!!`)
	document.write('<br><br><center><h1>Coronavírus bloqueado!</h1></center>')
}


// Autor: H. Giroto
// Fontes:
// 
